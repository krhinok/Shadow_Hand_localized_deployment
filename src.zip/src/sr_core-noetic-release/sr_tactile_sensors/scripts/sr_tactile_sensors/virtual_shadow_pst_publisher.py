#!/usr/bin/env python3
# Copyright 2011, 2022, 2023 Shadow Robot Company Ltd.
#
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the Free
# Software Foundation version 2 of the License.
#
# This program is distributed in the hope that it will be useful, but WITHOUT
# ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
# FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
# more details.
#
# You should have received a copy of the GNU General Public License along
# with this program. If not, see <http://www.gnu.org/licenses/>.

# This node combines 5 virtual touch sensors into a ShadowPST message compatible with etherCAT hand

from __future__ import absolute_import
import _thread
import rospy
from std_msgs.msg import Float64
from sr_robot_msgs.msg import ShadowPST


class MergeMessages:
    def __init__(self):
        rospy.init_node('ShadowPST_publisher', anonymous=True)
        self.ff_sub = rospy.Subscriber('/sr_tactile/touch/ff', Float64, self.ff_cb)
        self.mf_sub = rospy.Subscriber('/sr_tactile/touch/mf', Float64, self.mf_cb)
        self.rf_sub = rospy.Subscriber('/sr_tactile/touch/rf', Float64, self.rf_cb)
        self.lf_sub = rospy.Subscriber('/sr_tactile/touch/lf', Float64, self.lf_cb)
        self.th_sub = rospy.Subscriber('/sr_tactile/touch/th', Float64, self.th_cb)
        self.rate = rospy.Rate(25.0)
        self.pub = rospy.Publisher("/tactile", ShadowPST)
        self.pst = [0.0, 0.0, 0.0, 0.0, 0.0]
        self.mutex = _thread.allocate_lock()

    def ff_cb(self, msg):
        self.mutex.acquire()
        self.pst[0] = msg.data
        self.mutex.release()

    def mf_cb(self, msg):
        self.mutex.acquire()
        self.pst[1] = msg.data
        self.mutex.release()

    def rf_cb(self, msg):
        self.mutex.acquire()
        self.pst[2] = msg.data
        self.mutex.release()

    def lf_cb(self, msg):
        self.mutex.acquire()
        self.pst[3] = msg.data
        self.mutex.release()

    def th_cb(self, msg):
        self.mutex.acquire()
        self.pst[4] = msg.data
        self.mutex.release()

    def shadowpst_publisher(self):
        pst_state_msg = ShadowPST()
        pst_state_msg.temperature = [0, 0, 0, 0, 0, 0]
        pressure = []
        self.mutex.acquire()
        for i in range(0, 5):
            pressure.append(self.pst[i]*100)
        pst_state_msg.pressure = pressure
        # print pst_state_msg.pressure
        self.mutex.release()

        pst_state_msg.header.stamp = rospy.Time.now()
        self.pub.publish(pst_state_msg)


if __name__ == '__main__':
    merger = MergeMessages()
    while not rospy.is_shutdown():
        merger.shadowpst_publisher()
        merger.rate.sleep()
