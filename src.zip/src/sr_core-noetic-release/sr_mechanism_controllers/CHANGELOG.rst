^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sr_mechanism_controllers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.4.0 (2015-04-07)
------------------
* Adapt calibration controller
* Fix joint limit reading
* using prefix on joints didn't work with gazebo controllers. This is now working
* removed the divide by 2 for the velocity commands

1.3.1 (2014-07-18)
------------------

1.3.0 (2014-02-11)
------------------
* first hydro release

