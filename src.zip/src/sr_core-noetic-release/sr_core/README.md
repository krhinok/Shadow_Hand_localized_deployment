|     Service       |  Status  |
| ----------------- | -------- |
| Documentation     | [![Documentation Status](https://readthedocs.org/projects/shadow-robot-core-packages/badge/?version=latest)](http://shadow-robot-core-packages.readthedocs.org) |
| Code style checks | [![Circle CI](https://circleci.com/gh/shadow-robot/sr_core.svg?style=shield)](https://circleci.com/gh/shadow-robot/sr_core) |
| Unit tests        | [![Build Status](https://img.shields.io/shippable/55df21b21895ca4474103997.svg)](https://app.shippable.com/projects/55df21b21895ca4474103997) |


# Shadow Robot Core Packages
These are the core packages for the Shadow Robot hardware and simulation.
