The examples in this directory have been moved to the package sr_example
