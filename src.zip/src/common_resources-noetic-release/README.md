# CI Statuses

Check | Status
---|---
Build|[<img src="https://codebuild.eu-west-2.amazonaws.com/badges?uuid=eyJlbmNyeXB0ZWREYXRhIjoiYWl5ay9qYUN3OXZrM0xSVzBLeGswcWhqbFBGMnFtTHV4OGNrSUJPTDJkcVptVk53U3ZiSExFRERaN0tqSHlnNXFPWWpiV01yTWI4QTdQR0t3MXdodnBNPSIsIml2UGFyYW1ldGVyU3BlYyI6ImdlZWFyTE9KTU9QdHUwalkiLCJtYXRlcmlhbFNldFNlcmlhbCI6MX0%3D&branch=noetic-devel"/>](https://eu-west-2.console.aws.amazon.com/codesuite/codebuild/projects/auto_common_resources_noetic-devel_install_check/)
Style|[<img src="https://codebuild.eu-west-2.amazonaws.com/badges?uuid=eyJlbmNyeXB0ZWREYXRhIjoiTlE5YmZ4RjJoTW5Ea3VVUVVmMFRxUGExbnkvelUwTHZwWmFZVVp0VngyMXJ2VVlzMklFTGJlait4aHBCMVZONnd0VjRaNENlVjlaNUx5YTRqODY3eEk0PSIsIml2UGFyYW1ldGVyU3BlYyI6InEreGVHMDlsQWJGRlFkeWwiLCJtYXRlcmlhbFNldFNlcmlhbCI6MX0%3D&branch=noetic-devel"/>](https://eu-west-2.console.aws.amazon.com/codesuite/codebuild/projects/auto_common_resources_noetic-devel_style_check/)
Code Coverage|[<img src="https://codebuild.eu-west-2.amazonaws.com/badges?uuid=eyJlbmNyeXB0ZWREYXRhIjoiV2R1UUw0WGtmcllYOThQY2RIRVRBYXYvZm1rMnJXaHRHaEZyQS9iSzNaVG9MSEZaaDFSai9Ca3U1SWxQbUFRa2JQMysybmg3cU1DZkUzS0VSVk1aSWE4PSIsIml2UGFyYW1ldGVyU3BlYyI6IjVCVGVQZWo5N3hOckV5V2siLCJtYXRlcmlhbFNldFNlcmlhbCI6MX0%3D&branch=noetic-devel"/>](https://eu-west-2.console.aws.amazon.com/codesuite/codebuild/projects/auto_common_resources_noetic-devel_code_coverage/)

# common_resources
This repository contains resources that are common to all Shadow Robot's robots

