# sr_tests_template

A template package showing how to setup files for ros tests in python and c++.

## Usage

In the top level directory of your workspace run:
```sh
catkin_make run_tests_sr_tests_template
```