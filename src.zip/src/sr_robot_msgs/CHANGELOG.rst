^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sr_robot_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.4.0 (2015-04-07)
------------------
* Add a GraspArray message.
* Add PlanGrasp action.
* Port the Contact message and Grasp action from GSC

1.3.1 (2014-07-18)
------------------

1.3.0 (2014-02-11)
------------------
* first hydro release

